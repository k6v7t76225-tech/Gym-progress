GYM PROGRESS APP

Bestanden:
- index.html
- styles.css
- app.js
- manifest.json
- service-worker.js

Gebruik:
1. Publiceer deze map op een simpele webhost (bijv. GitHub Pages, Netlify of je eigen hosting).
2. Open de URL op iPhone in Safari.
3. Kies Deel -> Zet op beginscherm.
4. Daarna opent hij als zelfstandige app.

De app bewaart trainingsgegevens lokaal in de browser.
Gebruik de exportknop rechtsboven om regelmatig een JSON-backup te maken.

Progressieregel:
- Oefening heeft sets + min/max reps + verhogingsstap.
- Als ALLE sets de maximale reps halen, wordt volgend gewicht = huidig gewicht + stap.
- Anders blijft het gewicht gelijk.


TRAININGSDAGEN
Workout A - Borst Tricep:
Bankdrukken, Dumbbell Drukken, Dumbbell Fly, Triceps Pushdown,
Triceps Extension, Plank, Deadbug.

Workout B:
Optrekken, Lat Pulldown, Seated Row, Face Pull, Dumbbell Curl,
Hammer Curl, Ez-bar Curl, Hangend Knieën Optrekken, Plank.

Workout C - Benen Schouders:
Leg Press, Hip Thrust, Leg Extension, Leg Curl, Schouderdrukken,
Side Raise, Face Pull, Deadbug, Plank.


START WORKOUT FLOW
- Kies Workout A, B of C.
- Druk op 'Start workout'.
- De app toont één oefening tegelijk.
- Je ziet je vorige gewicht/reps en het aanbevolen gewicht.
- Vul je sets in en kies 'Opslaan & volgende'.
- Na de laatste oefening wordt de workout afgerond.
